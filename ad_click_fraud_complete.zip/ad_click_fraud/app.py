"""
Ad Click Fraud Detection - Backend API
Flask REST API with Random Forest + Logistic Regression ensemble
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
import re
import os
import json
import pickle
import logging
from datetime import datetime
from urllib.parse import urlparse

from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, classification_report
)

# ─── NumPy-safe JSON encoder ──────────────────────────────────────────────────
class NumpyEncoder(json.JSONEncoder):
    """Converts NumPy scalars/arrays to native Python types for JSON."""
    def default(self, obj):
        if isinstance(obj, np.integer):   return int(obj)
        if isinstance(obj, np.floating):  return float(obj)
        if isinstance(obj, np.bool_):     return bool(obj)
        if isinstance(obj, np.ndarray):   return obj.tolist()
        return super().default(obj)

# ─── App Setup ────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.json_encoder = NumpyEncoder          # use our encoder globally
CORS(app)  # Allow cross-origin requests from the frontend

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ─── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
DATA_PATH   = os.path.join(BASE_DIR, "data", "dataset.csv")
MODEL_DIR   = os.path.join(BASE_DIR, "models")
LOG_PATH    = os.path.join(BASE_DIR, "data", "analysis_log.json")
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, "data"), exist_ok=True)

# ─── Suspicious Keywords ──────────────────────────────────────────────────────
SUSPICIOUS_KEYWORDS = [
    "login", "verify", "secure", "account", "password", "free",
    "prize", "winner", "click", "confirm", "update", "urgent",
    "limited", "offer", "claim", "reward", "bank", "paypal",
    "amazon", "apple-id", "signin", "credential"
]

# ─── Feature Extraction ───────────────────────────────────────────────────────
def extract_features(url: str) -> dict:
    """Extract numerical features from a URL string."""
    parsed = urlparse(url)
    path   = parsed.path + "?" + parsed.query if parsed.query else parsed.path

    # 1. URL length
    url_length = len(url)

    # 2. Special character count (excluding slashes and dots)
    special_chars = len(re.findall(r'[!@#$%^&*()=+\[\]{};\'",<>?\\|`~]', url))

    # 3. Presence of an IP address instead of a domain
    has_ip = 1 if re.search(
        r'(\d{1,3}\.){3}\d{1,3}', parsed.netloc
    ) else 0

    # 4. Suspicious keyword count
    url_lower = url.lower()
    suspicious_keywords = sum(kw in url_lower for kw in SUSPICIOUS_KEYWORDS)

    # 5. HTTPS usage
    uses_https = 1 if parsed.scheme == "https" else 0

    # 6. Subdomain depth
    host = parsed.netloc.replace("www.", "")
    subdomain_count = max(0, host.count(".") - 1)

    # 7. Digit ratio in the URL
    digits = sum(c.isdigit() for c in url)
    digit_ratio = round(digits / max(len(url), 1), 4)

    return {
        "url_length":          url_length,
        "special_chars":       special_chars,
        "has_ip":              has_ip,
        "suspicious_keywords": suspicious_keywords,
        "uses_https":          uses_https,
        "subdomain_count":     subdomain_count,
        "digit_ratio":         digit_ratio,
    }

FEATURE_COLS = [
    "url_length", "special_chars", "has_ip",
    "suspicious_keywords", "uses_https", "subdomain_count", "digit_ratio"
]

# ─── Model State (in-memory) ──────────────────────────────────────────────────
state = {
    "rf_model":    None,
    "lr_model":    None,
    "scaler":      None,
    "metrics":     {},
    "feature_imp": {},
    "trained":     False,
}

# ─── Training ─────────────────────────────────────────────────────────────────
def train_models(csv_path: str = DATA_PATH):
    """Load CSV, train both models, evaluate, persist."""
    logger.info(f"Training from: {csv_path}")
    df = pd.read_csv(csv_path)

    # Validate required columns
    required = FEATURE_COLS + ["label"]
    missing  = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"CSV missing columns: {missing}")

    X = df[FEATURE_COLS].values
    y = df["label"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Scale features (for Logistic Regression)
    scaler  = StandardScaler()
    X_tr_sc = scaler.fit_transform(X_train)
    X_te_sc = scaler.transform(X_test)

    # ── Random Forest ──
    rf = RandomForestClassifier(n_estimators=100, random_state=42)
    rf.fit(X_train, y_train)
    rf_pred = rf.predict(X_test)

    # ── Logistic Regression ──
    lr = LogisticRegression(max_iter=1000, random_state=42)
    lr.fit(X_tr_sc, y_train)
    lr_pred = lr.predict(X_te_sc)

    # ── Metrics ──
    def get_metrics(y_true, y_pred, name):
        return {
            "name":      name,
            "accuracy":  round(accuracy_score(y_true, y_pred) * 100, 2),
            "precision": round(precision_score(y_true, y_pred, zero_division=0) * 100, 2),
            "recall":    round(recall_score(y_true, y_pred, zero_division=0) * 100, 2),
            "f1":        round(f1_score(y_true, y_pred, zero_division=0) * 100, 2),
        }

    metrics = {
        "random_forest":      get_metrics(y_test, rf_pred, "Random Forest"),
        "logistic_regression": get_metrics(y_test, lr_pred, "Logistic Regression"),
        "dataset_size":       len(df),
        "train_size":         len(X_train),
        "test_size":          len(X_test),
        "fraud_count":        int(y.sum()),
        "legit_count":        int((y == 0).sum()),
        "trained_at":         datetime.now().isoformat(),
    }

    # ── Feature Importance (Random Forest) ──
    feature_imp = {
        col: round(float(imp) * 100, 2)
        for col, imp in zip(FEATURE_COLS, rf.feature_importances_)
    }

    # ── Persist ──
    pickle.dump(rf,     open(os.path.join(MODEL_DIR, "rf.pkl"),     "wb"))
    pickle.dump(lr,     open(os.path.join(MODEL_DIR, "lr.pkl"),     "wb"))
    pickle.dump(scaler, open(os.path.join(MODEL_DIR, "scaler.pkl"), "wb"))
    json.dump(metrics,     open(os.path.join(MODEL_DIR, "metrics.json"),     "w"), indent=2)
    json.dump(feature_imp, open(os.path.join(MODEL_DIR, "feature_imp.json"), "w"), indent=2)

    # Update in-memory state
    state.update({
        "rf_model":    rf,
        "lr_model":    lr,
        "scaler":      scaler,
        "metrics":     metrics,
        "feature_imp": feature_imp,
        "trained":     True,
    })

    logger.info(f"Training complete. RF accuracy: {metrics['random_forest']['accuracy']}%")
    return metrics

def load_models():
    """Load persisted models if they exist."""
    try:
        state["rf_model"]    = pickle.load(open(os.path.join(MODEL_DIR, "rf.pkl"),     "rb"))
        state["lr_model"]    = pickle.load(open(os.path.join(MODEL_DIR, "lr.pkl"),     "rb"))
        state["scaler"]      = pickle.load(open(os.path.join(MODEL_DIR, "scaler.pkl"), "rb"))
        state["metrics"]     = json.load(open(os.path.join(MODEL_DIR, "metrics.json")))
        state["feature_imp"] = json.load(open(os.path.join(MODEL_DIR, "feature_imp.json")))
        state["trained"]     = True
        logger.info("Loaded persisted models.")
    except FileNotFoundError:
        logger.info("No saved models found — training fresh from dataset.")
        train_models()

# ─── Prediction ───────────────────────────────────────────────────────────────
def predict_url(url: str) -> dict:
    """Run ensemble prediction on a URL and return full result dict."""
    features   = extract_features(url)
    X          = np.array([[features[c] for c in FEATURE_COLS]])
    X_scaled   = state["scaler"].transform(X)

    rf = state["rf_model"]
    lr = state["lr_model"]

    # Probabilities from each model
    rf_prob = rf.predict_proba(X)[0][1]        # P(fraud)
    lr_prob = lr.predict_proba(X_scaled)[0][1] # P(fraud)

    # Ensemble: weighted average (RF slightly more weight)
    ensemble_prob = float(0.6 * rf_prob + 0.4 * lr_prob)
    risk_score    = round(ensemble_prob * 100, 1)

    # Verdict
    is_fraud = bool(ensemble_prob >= 0.5)

    # Confidence: distance from 0.5 → 0-100 scale
    confidence = round(abs(ensemble_prob - 0.5) * 200, 1)

    return {
        "url":           url,
        "verdict":       "Fraudulent" if is_fraud else "Legitimate",
        "is_fraud":      is_fraud,
        "risk_score":    risk_score,
        "confidence":    confidence,
        "model_scores": {
            "random_forest":       round(float(rf_prob) * 100, 1),
            "logistic_regression": round(float(lr_prob) * 100, 1),
        },
        "features":      features,
        "analysed_at":   datetime.now().isoformat(),
    }

# ─── Log Helpers ──────────────────────────────────────────────────────────────
def append_log(entry: dict):
    """Append an analysis to the JSON log file."""
    log = []
    if os.path.exists(LOG_PATH):
        try:
            log = json.load(open(LOG_PATH))
        except Exception:
            log = []
    log.insert(0, entry)   # newest first
    log = log[:100]        # keep last 100
    json.dump(log, open(LOG_PATH, "w"), indent=2)

def read_log() -> list:
    if not os.path.exists(LOG_PATH):
        return []
    try:
        return json.load(open(LOG_PATH))
    except Exception:
        return []

# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "trained": state["trained"]})


@app.route("/api/analyse", methods=["POST"])
def analyse():
    """Analyse a URL for ad click fraud."""
    if not state["trained"]:
        return jsonify({"error": "Models not trained yet. Call /api/train first."}), 503

    data = request.get_json(silent=True) or {}
    url  = (data.get("url") or "").strip()

    if not url:
        return jsonify({"error": "No URL provided."}), 400

    # Basic URL sanity check
    if not re.match(r'^https?://', url):
        url = "http://" + url  # add scheme if missing

    try:
        result = predict_url(url)
        append_log(result)
        return jsonify(result)
    except Exception as e:
        logger.exception("Prediction failed")
        return jsonify({"error": str(e)}), 500


@app.route("/api/train", methods=["POST"])
def retrain():
    """Re-train models. Optionally upload a new CSV."""
    csv_path = DATA_PATH

    if "file" in request.files:
        f = request.files["file"]
        if f.filename.endswith(".csv"):
            csv_path = os.path.join(BASE_DIR, "data", "uploaded_dataset.csv")
            f.save(csv_path)
        else:
            return jsonify({"error": "Only CSV files accepted."}), 400

    try:
        metrics = train_models(csv_path)
        return jsonify({"message": "Training complete.", "metrics": metrics})
    except Exception as e:
        logger.exception("Training failed")
        return jsonify({"error": str(e)}), 500


@app.route("/api/metrics", methods=["GET"])
def metrics():
    """Return model performance metrics."""
    if not state["trained"]:
        return jsonify({"error": "Models not trained."}), 503
    return jsonify({
        "metrics":      state["metrics"],
        "feature_imp":  state["feature_imp"],
    })


@app.route("/api/history", methods=["GET"])
def history():
    """Return recent analysis log."""
    limit = min(int(request.args.get("limit", 20)), 100)
    return jsonify(read_log()[:limit])


@app.route("/api/history", methods=["DELETE"])
def clear_history():
    """Clear the analysis log."""
    if os.path.exists(LOG_PATH):
        os.remove(LOG_PATH)
    return jsonify({"message": "History cleared."})


# ─── Startup ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    load_models()
    app.run(debug=True, host="0.0.0.0", port=5000)

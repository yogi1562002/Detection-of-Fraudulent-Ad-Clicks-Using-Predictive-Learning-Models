# 🛡 AdGuard — Ad Click Fraud Detection

A full-stack machine learning application that detects fraudulent ad clicks using a Random Forest + Logistic Regression ensemble.

---

## 📁 Project Structure

```
ad_click_fraud/
├── app.py                  # Flask backend + ML API
├── requirements.txt        # Python dependencies
├── data/
│   └── dataset.csv         # Labelled training data (100 URLs)
├── models/                 # Auto-generated after first train
│   ├── rf.pkl
│   ├── lr.pkl
│   ├── scaler.pkl
│   ├── metrics.json
│   └── feature_imp.json
└── frontend/
    └── index.html          # Single-file frontend (no build needed)
```

---

## ⚙️ Setup & Installation

### Prerequisites
- Python 3.9+
- A modern browser

### 1. Create a virtual environment (recommended)

```bash
cd ad_click_fraud
python -m venv venv
source venv/bin/activate          # Linux / macOS
venv\Scripts\activate             # Windows
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

---

## 🚀 Running the Application

### Step 1: Start the Flask backend

```bash
python app.py
```

You should see:
```
Training from: .../data/dataset.csv
Training complete. RF accuracy: XX%
 * Running on http://0.0.0.0:5000
```

The backend automatically trains the models on first launch.

### Step 2: Open the frontend

Simply open `frontend/index.html` in your browser:

```bash
# macOS
open frontend/index.html

# Linux
xdg-open frontend/index.html

# Windows
start frontend/index.html
```

Or drag-and-drop the file into your browser.

---

## 🔌 API Endpoints

| Method | Endpoint        | Description                          |
|--------|----------------|--------------------------------------|
| GET    | /api/health    | Health check + trained status        |
| POST   | /api/analyse   | Analyse a URL for fraud              |
| GET    | /api/metrics   | Model accuracy + feature importance  |
| GET    | /api/history   | Recent analyses (max 100)            |
| DELETE | /api/history   | Clear analysis log                   |
| POST   | /api/train     | Retrain models (optionally with CSV) |

### Example — Analyse a URL

```bash
curl -X POST http://localhost:5000/api/analyse \
  -H "Content-Type: application/json" \
  -d '{"url": "http://192.168.1.1/login/verify/secure"}'
```

Response:
```json
{
  "url": "http://192.168.1.1/login/verify/secure",
  "verdict": "Fraudulent",
  "is_fraud": true,
  "risk_score": 91.4,
  "confidence": 82.8,
  "model_scores": {
    "random_forest": 94.0,
    "logistic_regression": 87.0
  },
  "features": {
    "url_length": 38,
    "special_chars": 3,
    "has_ip": 1,
    "suspicious_keywords": 2,
    "uses_https": 0,
    "subdomain_count": 0,
    "digit_ratio": 0.21
  },
  "analysed_at": "2024-01-15T12:34:56"
}
```

---

## 📊 Features Extracted from URLs

| Feature             | Description                                      |
|--------------------|--------------------------------------------------|
| url_length          | Total character length of the URL               |
| special_chars       | Count of non-alphanumeric special characters    |
| has_ip              | 1 if the host is an IP address, else 0          |
| suspicious_keywords | Count of keywords like login, verify, secure    |
| uses_https          | 1 if HTTPS, 0 if HTTP                           |
| subdomain_count     | Number of subdomains beyond www                 |
| digit_ratio         | Proportion of digits in the URL                 |

---

## 📂 Custom Training Data

Your CSV must include these columns:

```
url, url_length, special_chars, has_ip, suspicious_keywords, 
uses_https, subdomain_count, digit_ratio, label
```

Where `label` is `1` (fraudulent) or `0` (legitimate).

Retrain via the UI or API:

```bash
curl -X POST http://localhost:5000/api/train \
  -F "file=@my_dataset.csv"
```

---

## 🐳 Docker (Optional)

Create a `Dockerfile`:

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "app.py"]
```

Build and run:

```bash
docker build -t adguard .
docker run -p 5000:5000 adguard
```

---

## 🧠 Models

- **Random Forest** (100 trees) — handles non-linear feature interactions, provides feature importance
- **Logistic Regression** — fast linear baseline with scaled features
- **Ensemble** — weighted average (60% RF, 40% LR) for final verdict

---

## ⚠️ CORS Note

If your browser blocks API calls, install the `flask-cors` package (already in requirements.txt). For production, restrict CORS origins in `app.py`.
